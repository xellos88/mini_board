    <h1><a href  ="board_list.php" class="">Board Mini</a></h1>
